const { MessageEmbed } = require("discord.js");

module.exports = {
  name: "disconnect",
  description: "音楽を止めて音声チャンネルを離れる",
  usage: "",
  permissions: {
    channel: ["VIEW_CHANNEL", "SEND_MESSAGES", "EMBED_LINKS"],
    member: [],
  },
  aliases: ["leave", "exit", "quit", "dc", "stop"],
  /**
   *
   * @param {import("../structures/DiscordMusicBot")} client
   * @param {import("discord.js").Message} message
   * @param {string[]} args
   * @param {*} param3
   */
  run: async (client, message, args, { GuildDB }) => {
    let player = await client.Manager.get(message.guild.id);
    if (!message.member.voice.channel)
      return client.sendTime(
        message.channel,
        "❌ | このコマンドを使用して、音声チャンネルにいる必要があります"
      );
    if (!player)
      return client.sendTime(
        message.channel,
        "❌ | 今は何も遊んでいません..."
      );
    await client.sendTime(message.channel, ":notes: | 切断されました!");
    await message.react("✅");
    player.destroy();
  },

  SlashCommand: {
    /**
     *
     * @param {import("../structures/DiscordMusicBot")} client
     * @param {import("discord.js").Message} message
     * @param {string[]} args
     * @param {*} param3
     */
    run: async (client, interaction, args, { GuildDB }) => {
      const guild = client.guilds.cache.get(interaction.guild_id);
      const member = guild.members.cache.get(interaction.member.user.id);

      if (!member.voice.channel)
        return client.sendTime(
          interaction,
          "❌ | このコマンドを使用するには、音声チャンネルにいる必要があります。"
        );
      if (
        guild.me.voice.channel &&
        !guild.me.voice.channel.equals(member.voice.channel)
      )
        return client.sendTime(
          interaction,
          `❌ | このコマンドを使用するには、　${guild.me.voice.channel} にいる必要があります。`
        );

      let player = await client.Manager.get(interaction.guild_id);
      if (!player)
        return client.sendTime(
          interaction,
          "❌ | 今は何も遊んでいません..."
        );
      player.destroy();
      client.sendTime(interaction, ":notes: | 切断されました!");
    },
  },
};
