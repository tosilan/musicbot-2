const { MessageEmbed } = require("discord.js");
const { TrackUtils } = require("erela.js");

module.exports = {
  name: "pause",
  description: "音楽を一時停止する",
  usage: "",
  permissions: {
    channel: ["VIEW_CHANNEL", "SEND_MESSAGES", "EMBED_LINKS"],
    member: [],
  },
  aliases: [],
  /**
   *
   * @param {import("../structures/DiscordMusicBot")} client
   * @param {import("discord.js").Message} message
   * @param {string[]} args
   * @param {*} param3
   */
  run: async (client, message, args, { GuildDB }) => {
    let player = await client.Manager.get(message.guild.id);
    if (!player)
      return client.sendTime(
        message.channel,
        "❌ | 今は何も遊んでいません..."
      );
    if (!message.member.voice.channel)
      return client.sendTime(
        message.channel,
        "❌ | このコマンドを使用するには、音声チャンネルにいる必要があります!"
      );
    if (
      message.guild.me.voice.channel &&
      message.member.voice.channel.id !== message.guild.me.voice.channel.id
    )
      return client.sendTime(
        message.channel,
        ":x: | このコマンドを使用するには、私と同じ音声チャンネルにいる必要があります。"
      );
    if (player.paused)
      return client.sendTime(
        message.channel,
        "❌ | 音楽はすでに一時停止しています!"
      );
    player.pause(true);
    let embed = new MessageEmbed()
      .setAuthor(`一時停止したよ!`, client.botconfig.IconURL)
      .setColor(client.botconfig.EmbedColor)
      .setDescription(`Type \`${GuildDB.prefix}resume\` to continue playing!`);
    await message.channel.send(embed);
    await message.react("✅");
  },

  SlashCommand: {
    /**
     *
     * @param {import("../structures/DiscordMusicBot")} client
     * @param {import("discord.js").Message} message
     * @param {string[]} args
     * @param {*} param3
     */
    run: async (client, interaction, args, { GuildDB }) => {
      const guild = client.guilds.cache.get(interaction.guild_id);
      const member = guild.members.cache.get(interaction.member.user.id);

      if (!member.voice.channel)
        return client.sendTime(
          interaction,
          "❌ | このコマンドを使用するには、音声チャンネルにいる必要があります。"
        );
      if (
        guild.me.voice.channel &&
        !guild.me.voice.channel.equals(member.voice.channel)
      )
        return client.sendTime(
          interaction,
          ":x: | このコマンドを使用するには、私と同じ音声チャンネルにいる必要があります。"
        );

      let player = await client.Manager.get(interaction.guild_id);
      if (!player)
        return client.sendTime(
          interaction,
          "❌ | 今は何も遊んでいません..."
        );
      if (player.paused)
        return client.sendTime(interaction, "音楽はすでに一時停止しています!");
      player.pause(true);
      client.sendTime(interaction, "**⏸ 一時停止したよ!**");
    },
  },
};
